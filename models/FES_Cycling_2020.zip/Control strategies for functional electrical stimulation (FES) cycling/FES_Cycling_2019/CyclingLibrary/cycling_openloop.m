function [u] = cycling_openloop( k )
    u = k;
end

